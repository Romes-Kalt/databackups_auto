import time


def is_dst():
    if len(time.tzname) == 2:
        return time.tzname[0] != time.tzname[1]
    return None


if __name__ == "__main__":
    print(is_dst())

