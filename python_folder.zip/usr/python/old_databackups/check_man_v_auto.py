import subprocess
import os
from pathlib import Path
import json
import colorama
from typing import List, Dict
from deepdiff import DeepDiff


def find_csv_diffs(
    file1: str = "./data3.csv", file2: str = "./data4.csv"
) -> List[str]:
    if not Path(file1).is_file():
        print(f"{file1} not found.")
        return [f"{file1} not found."]
    if not Path(file2).is_file():
        print(f"{file2} not found.")
        return [f"{file2} not found."]
    if os.stat(file1).st_size == 0:
        print(f"{file1} is empty.")
        return [f"{file1} is empty."]
    if os.stat(file2).st_size == 0:
        print(f"{file2} is empty.")
        return [f"{file2} is empty."]
    with open(file1, "r", encoding="utf8") as fi:
        lst1 = fi.read().splitlines()
    with open(file2, "r", encoding="utf8") as fi:
        lst2 = fi.read().splitlines()
    if len(lst1) == len(lst2):
        return [f"{file1} and {file2} identical."]
    if len(lst1) > len(lst2):
        res_lst = list(set(lst1) - set(lst2))
        res_lst.insert(0, file1)
        return res_lst
    res_lst = list(set(lst2) - set(lst1))
    res_lst.insert(0, file2)
    return res_lst


def check_flight_data_lines():
    """HARDCODED filepaths."""
    
    # get the line counts from both files
    result = subprocess.run([
        "wc", 
        "-l", 
        "/usr/python/combined_scraper/databackups_auto/flight_data_plus.csv"
        ], stdout=subprocess.PIPE)
    auto_result = int(result.stdout.decode("utf-8").split(" ")[0])
    
    result = subprocess.run([
        "wc",
        "-l", 
        "/usr/python/old_databackups/databackups/flight_data.csv"
        ], stdout=subprocess.PIPE)
    man_result = int(result.stdout.decode("utf-8").split(" ")[0])
    if auto_result == man_result:
        print(colorama.Fore.GREEN + "   flight_data.csv  ", end="")
    else:
        print(colorama.Fore.RED + "   flight_data.csv  ", end="")
        for _ in find_csv_diffs(
            "/usr/python/old_databackups/databackups/flight_data.csv",
            "/usr/python/combined_scraper/databackups_auto/flight_data_plus.csv",
            ):
            print(_)
    print(
        colorama.Fore.WHITE
        + f"{str((auto_result) == (man_result))}: auto {auto_result:>7} <->"
        f" {man_result:>7} manual"
    )
    return auto_result == man_result


def count_flights(fp: str = None):
    """Hardcoded filepaths."""
    
    with open(fp, "r", encoding="cp1252") as f:
        flights = json.load(f)
    num_flights_auto = []
    for d in flights.keys():
        for al in flights[d].keys():
            if type(flights[d][al]) == dict:
                for f in flights[d][al]:
                    if type(flights[d][al][f]) == dict:
                        num_flights_auto.append((len(flights[d][al][f].keys())))
    return num_flights_auto


def print_json_diff(fp1, fp2):
    with open(fp1, "r", encoding="utf8") as fi:
        fp1_dct = json.load(fi)
    with open(fp2, "r", encoding="utf8") as fi:
        fp2_dct = json.load(fi)
    print(DeepDiff(fp1_dct, fp2_dct))


def check_jsons():
    """Harcoded."""
    # BER ezy
    lst_ezy_auto = count_flights(
            "/usr/python/combined_scraper/databackups_auto/BERezy_flights_plus.json"
            )
    lst_ezy_man = count_flights(
            "/usr/python/old_databackups/databackups/BERezy_flights.json"
            )
    if len(lst_ezy_auto) == len(lst_ezy_man):
        print(colorama.Fore.GREEN + "BERezy_flights.json", end="")
    else:
        print(colorama.Fore.RED + "BERezy_flights.json", end="")
#        print(colorama.Fore.WHITE)
#        print_json_diff(
#                "/usr/python/combined_scraper/databackups_auto/BERezy_flights_plus.json",
#                "/usr/python/old_databackups/databackups/BERezy_flights.json"
#                )
    print(
        colorama.Fore.WHITE
        + f" {len(lst_ezy_auto) == len(lst_ezy_man)}: "
        f"auto {len(lst_ezy_auto):>7} <-> {len(lst_ezy_man):>7} manual"
    ) 

    # BER all airlines
    lst_all_auto = count_flights(
            "/usr/python/combined_scraper/databackups_auto/BERall_flights_plus.json"
            )
    lst_all_man = count_flights(
            "/usr/python/old_databackups/databackups/BERall_flights.json"
            )
    if len(lst_all_auto) == len(lst_all_man):
        print(colorama.Fore.GREEN + "BERall_flights.json", end="")
    else:
        print(colorama.Fore.RED + "BERall_flights.json", end="")
#        print(colorama.Fore.WHITE)
#        print_json_diff(
#                "/usr/python/combined_scraper/databackups_auto/BERezy_flights_plus.json",
#                "/usr/python/old_databackups/databackups/BERezy_flights.json"
#                )
    print(
        colorama.Fore.WHITE
        + f" {len(lst_all_auto) == len(lst_all_man)}: "
        f"auto {len(lst_all_auto):>7} <-> {len(lst_all_man):>7} manual"
    )


def main():
    """Run main function."""

    # pull latest numbers from git
    os.chdir("/usr/python/old_databackups/databackups")
    subprocess.run(["git", "fetch"])
    subprocess.run(["git", "pull"])
    print("########################################")
    print("############### CHECKING ###############")
    print("########################################")
    check_flight_data_lines()

    check_jsons()


if __name__ == "__main__":
    main()

