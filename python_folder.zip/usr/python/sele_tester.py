import logging
import datetime as dt
import json
import codecs
import time
import random
import smtplib
import selenium
from selenium import webdriver  # , common
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

#WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
#LOG_FILEPATH_JSON = " /usr/bin/python/combined_scraper/log/json_scraper.log"
#LOG_FILEPATH_DEPARR = " /usr/bin/python/combined_scraper/log/deparr_scraper.log"
#LOG_FILEPATH_COMB = "/usr/bin/python/combined_scraper/log/combined_scraper.log"
#EZY_JSON_FP = "/usr/bin/python/combined_scraper/data/ezy.json"
#ALL_FLIGHTS_FP = "/usr/bin/python/combined_scraper/data/all_flights.json"
#FLIGHTS_DATA_FP = "/usr/bin/python/combined_scraper/data/flight_data.csv"
#TODAY = dt.datetime.strftime(dt.datetime.now(), "%Y_%m_%d")
#YESTERDAY = (dt.datetime.now() - dt.timedelta(1)).strftime("%Y_%m_%d")
#YESTERDAY_ = (dt.datetime.now() - dt.timedelta(2)).strftime("%Y_%m_%d")
#FLIGHT_CHECK = []  # note EZYs in both runs
#CHROMEDRIVER_PATH = "/usr/local/bin/chromedriver"
#WINDOW_SIZE = "1920,1080"


def set_up_logger(filepath: str = "./log/log.log"):
    """Set up logger."""
    logging.basicConfig(
        level=logging.INFO,
        filename=filepath,
        filemode="a",
        format="%(asctime)s - %(levelname)8s - %(funcName)25s() - %(message)s",
    )


def wait():
    """creates a random time window to mask webdriver"""
    time.sleep(random.randint(3, 5))


def scrape_airl(airline: str = ""):
    """PROJECT-SPECIFIC.

    Opens BER website and scrapes departures for airline for TODAY
    and retuns as list of tuples (flightnum, time, desti_code)
    """
    if not airline:
        airline = "all airlines"
    logging.info("Starting scraping for departures by %s.", airline)

    dep_lst = []
    s = Service("C:/Users/.../chromedriver.exe")
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--window-size=%s" % WINDOW_SIZE)
    chrome_options.add_argument("--no-sandbox")
    driver = webdriver.Chrome(service=s, options=chrome_options)





import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

CHROMEDRIVER_PATH = '/usr/bin/'
WINDOW_SIZE = "1920,1080"



if __name__ == "__main__":
    s = Service("/usr/bin/chromedriver.exe")
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--window-size=%s" % WINDOW_SIZE)
    chrome_options.add_argument("--no-sandbox")
    driver = webdriver.Chrome(service=s, options=chrome_options)
    driver.get("https://www.rki.de/DE/Content/InfAZ/N/Neuartiges_Coronavirus/Daten/Fallzahlen_Kum_Tab.html")
    time.sleep(2)
    driver.find_element(By.CLASS_NAME, "button.right.close").click()  # cookie window
    print("cookie window closed")
    time.sleep(4)
    x = driver.find_elements(By.CSS_SELECTOR, "h2")
    print(x[14].text.split("Stand: ")[1])
